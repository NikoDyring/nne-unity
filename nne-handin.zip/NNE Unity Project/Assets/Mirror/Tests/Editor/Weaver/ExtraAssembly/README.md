We need this extra Assembly when testing multiple assembles. 

Weaver is currently unable to use reference to assembles that are not in `CompilationPipeline.GetAssemblies()`