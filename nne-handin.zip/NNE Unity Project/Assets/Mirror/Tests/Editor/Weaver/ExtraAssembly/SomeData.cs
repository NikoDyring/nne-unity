namespace Mirror.Weaver.Tests.Extra
{
    public struct SomeData
    {
        public int usefulNumber;
    }
}
