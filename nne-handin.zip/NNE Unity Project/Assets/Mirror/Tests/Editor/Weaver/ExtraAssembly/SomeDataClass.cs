namespace Mirror.Weaver.Tests.Extra
{
    public class SomeDataClass
    {
        public int usefulNumber;
    }
}
