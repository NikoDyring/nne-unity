﻿using UnityEngine;

public class DataCube : MonoBehaviour
{
    public int ID;
    public string Name;
    public string Info;
    public float Percentage;
    public string LastEdit;
    public string DetailedDescription;
}
